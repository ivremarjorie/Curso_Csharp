﻿using System;

namespace Exemplo_02
{
    class Program
    {
        static void Main(string[] args)
        {
            // double nota1, nota2, media;
            // string nome;
            // bool teste;

            double num1, num2, soma;

            Console.WriteLine("Digite o primeiro número: ");
            num1 = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o segundo número: ");
            num2 = double.Parse(Console.ReadLine());
            soma = num1 + num2; 
            Console.WriteLine("A soma dos números é: " + soma);
            Console.ReadKey();


        }
    }
}
